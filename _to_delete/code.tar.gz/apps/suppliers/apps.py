from django.apps import AppConfig


class SuppliersConfig(AppConfig):
    name = "apps.suppliers"
    verbose_name = "Suppliers & purchase orders"
